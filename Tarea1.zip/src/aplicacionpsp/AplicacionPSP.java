package aplicacionpsp;

import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

import javax.swing.*;

public class AplicacionPSP extends JFrame{
    
    private ArrayList <Cliente> clientes;
    
    int cont = 0;
    
    private JLabel numeroLabel;
    private JLabel nombreLabel;
    private JLabel edadLabel;
    private JLabel saldoLabel;
    
    private TextField numeroField;
    private TextField nombreField;
    private TextField edadField;
    private TextField saldoField;
    
    private JButton retroceder;
    private JButton avanzar;
    
    public AplicacionPSP(){
        super("Daniel Hidalgo");
        
        Cliente cliente1 = new Cliente(1, "Manolo", 23, 4500.50);
        Cliente cliente2 = new Cliente(2, "Jose", 45, 126000.35);
        Cliente cliente3 = new Cliente(3, "Samu", 33, 700);
        Cliente cliente4 = new Cliente(4, "Antonio", 15, 150.60);
        Cliente cliente5 = new Cliente(5, "Juan", 80, 60000);
        clientes = new ArrayList();
        clientes.add(cliente1);
        clientes.add(cliente2);
        clientes.add(cliente3);
        clientes.add(cliente4);
        clientes.add(cliente5);
        
        numeroLabel = new JLabel("Numero: ");
        nombreLabel = new JLabel("Nombre: ");
        edadLabel = new JLabel("Edad: ");
        saldoLabel = new JLabel("Saldo: ");
        
        numeroField = new TextField(10);
        numeroField.setText(String.valueOf(cliente1.getCodigo()));
        nombreField = new TextField(10);
        nombreField.setText(cliente1.getNombre());
        edadField = new TextField(10);
        edadField.setText(String.valueOf(cliente1.getEdad()));
        saldoField = new TextField(10);
        saldoField.setText(String.valueOf(cliente1.getSaldo()));
        
        retroceder = new JButton("<");
        avanzar = new JButton(">");
        
        retroceder.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e){
                if(cont > 0){
                    cont--;
                    actualizarVista();
                }
            }
        });
        
        retroceder.setEnabled(false);
        
        avanzar.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e){
                if(cont < 5){
                    cont++;
                    actualizarVista();
                }
            }
        });
        
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(0, 1));
        panel.add(numeroLabel);
        panel.add(nombreLabel);
        panel.add(edadLabel);
        panel.add(saldoLabel);
        
        JPanel panel2 = new JPanel();
        panel2.setLayout(new GridLayout(0, 1));
        panel2.add(numeroField);
        panel2.add(nombreField);
        panel2.add(edadField);
        panel2.add(saldoField);
        
        JPanel panel3 = new JPanel();
        panel3.setLayout(new GridLayout(1, 0));
        panel3.add(retroceder);
        panel3.add(avanzar);
        
        JPanel contentPane = new JPanel();
        contentPane.setBorder(
               BorderFactory.createEmptyBorder(20, 20, 20, 20));
        contentPane.setLayout(new BorderLayout());
        contentPane.add(panel, BorderLayout.CENTER);
        contentPane.add(panel2, BorderLayout.EAST);
        contentPane.add(panel3, BorderLayout.SOUTH);
        
        setContentPane(contentPane);
        
    }
    
    public void actualizarVista(){
        Cliente cliente = clientes.get(cont);
        numeroField.setText(String.valueOf(cliente.getCodigo()));
        nombreField.setText(cliente.getNombre());
        edadField.setText(String.valueOf(cliente.getEdad()));
        saldoField.setText(String.valueOf(cliente.getSaldo()));

        retroceder.setEnabled(cont > 0);
        avanzar.setEnabled(cont < clientes.size() - 1);
    }
    
    public static void main(String[] args) {
        final AplicacionPSP app = new AplicacionPSP();
        
        app.addWindowListener(new WindowAdapter(){
            @Override
            public void windowClosing(WindowEvent e){
                System.exit(0);
            }
        });
        
        app.pack();
        app.setVisible(true);
    }
}

