package aplicacionpsp;

public class Cliente {
    private int codigo;
    private String nombre;
    private int edad;
    private double saldo;

    public Cliente(int codigo, String nombre, int edad, double saldo) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.edad = edad;
        this.saldo = saldo;
    }

    Cliente(Cliente get) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }
    
    public String toString(){
        return "Codigo: " + codigo + " Nombre: " + nombre + " Edad: " + edad + " Saldo: " + saldo;
    }
}
