package Controlador;

import javax.swing.DefaultListModel;
import javax.swing.JList;
import javax.swing.JScrollPane;

public class PanelJLista extends javax.swing.JPanel{
    public PanelJLista(Lista <Object> objetos) {
        initComponents(objetos);
    }

    private void initComponents(Lista <Object> objetos) {
        JScrollPane jScrollPanel = new javax.swing.JScrollPane();
        JList<Object> jList1 = new javax.swing.JList<>();
        //Codigo
        jList1.setModel(modeloLista(objetos));
        jScrollPanel.setViewportView(jList1);
        //Codigo
    }

    private DefaultListModel modeloLista(Lista <Object> objetos){
        
        DefaultListModel<String> modelo = new DefaultListModel<>();
        //Codigo
        if (objetos != null && !objetos.estaVacia()){
            objetos.mostrarLista();         
        }else
            modelo.addElement("No hay elementos");
            return modelo;
    }
}
