package Controlador;

public class ControlErrores extends Exception{
    public ControlErrores(String mensaje){
        super(mensaje);
    }
}
