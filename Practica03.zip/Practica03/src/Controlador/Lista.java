package Controlador;

import java.io.Serializable;
import Modelo.*;

public class Lista <E> implements Serializable{
    private Node<E> inicio;
    private Node<E> actual;
    
    public Lista(){
        this.inicio = null;
        this.actual = inicio;
    }
    
    public String mostrarLista(){     // Es de prueba
        Node<E> aux = this.inicio;
        String texto = "";
        while (aux != null){
            texto +=  aux.getPrincipal().toString();
            aux=aux.getSiguiente();
        }
        return texto;
    }
    
    public Node<E> getPrimero(){
        return this.inicio;
    }
    
    public void avanzar() {
        if (this.actual != null && this.actual.getSiguiente() != null) {
            this.actual = this.actual.getSiguiente();
        }
    }

    public void retroceder() {
        if (this.actual != null && this.actual.getAnterior() != null) {
            this.actual = this.actual.getAnterior();
        }
    }
    
    public boolean estaVacia(){
        if(this.inicio == null){
            return true;
        }else return false;
    }
    
    public void insertarNodo(E p){
        Node<E> nuevoNodo = new Node(p);
        if(this.estaVacia()){
            this.inicio = nuevoNodo;
            this.actual = nuevoNodo;
        }else{
            this.getActual().setSiguiente(nuevoNodo);
            nuevoNodo.setAnterior(this.getActual());
            this.actual = nuevoNodo;
        }
    }
    
    public Node<E> getActual(){
        return this.actual;
    }
    
    public void setActual(Node<E> actual){
        this.actual = actual;
    }
    
    public class Node<E> implements Serializable{
        private Node<E> siguiente;
        private Node<E> anterior;
        E principal;
        
        public Node(E p){
            this.siguiente = null;
            this.principal = p;  
            this.anterior = null;
        }
        
        public Node<E> getSiguiente() {
            return this.siguiente;
        }

        public void setSiguiente(Node<E> siguiente) {
            this.siguiente = siguiente;
        }

        public E getPrincipal() {
            return principal;
        }

        public void setPrincipal(E p) {
            this.principal = p;
        }
        
        public Node<E> getAnterior(){
            return this.anterior;
        }
        
        public void setAnterior(Node<E> anterior){
            this.anterior = anterior;
        }
    }
}
