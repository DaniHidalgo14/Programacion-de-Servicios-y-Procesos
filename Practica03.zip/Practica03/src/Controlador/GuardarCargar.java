package Controlador;

import Modelo.*;
import java.io.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class GuardarCargar<E> implements Serializable{
    ObjectOutputStream salida;
    ObjectInputStream entrada;
    
    public void guardarDatosInsertados(Coche coche) throws ClassNotFoundException{
        Lista<E> listaAux = new Lista();
        try{
            entrada = new ObjectInputStream(new FileInputStream("fichero.txt"));
            listaAux = (Lista<E>)entrada.readObject();
            entrada.close();
        }catch(IOException ex){
            System.out.println("ERROR: No se pudieron leer los datos");
        }
        listaAux.insertarNodo((E) coche);
        try{
            salida = new ObjectOutputStream(new FileOutputStream("fichero.txt"));
            salida.writeObject(listaAux);
            salida.close();
        }catch(IOException ex){
            System.out.println("ERROR: No se pudieron guardar los datos");
        }
    }
    
    public void guardarDatosModificados(Coche coche) throws ClassNotFoundException{
        Lista<E> listaAux = new Lista();
        try{
            entrada = new ObjectInputStream(new FileInputStream("fichero.txt"));
            listaAux = (Lista<E>)entrada.readObject();
            entrada.close();
        }catch(IOException ex){
            System.out.println("ERROR: No se pudieron leer los datos");
        }
        listaAux.getActual().setPrincipal((E) coche);
        try{
            salida = new ObjectOutputStream(new FileOutputStream("fichero.txt"));
            salida.writeObject(listaAux);
            salida.close();
        }catch(IOException ex){
            System.out.println("ERROR: No se pudieron guardar los datos");
        }
    }
    
    public Lista cargarDatos(){
        Lista <E> miLista = new Lista();
        try{
            entrada = new ObjectInputStream(new FileInputStream("fichero.txt"));
            miLista = (Lista<E>) entrada.readObject();
            entrada.close();
        }catch(IOException ex){
            System.out.println("ERROR: No se pudieron descargar los datos");
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(GuardarCargar.class.getName()).log(Level.SEVERE, null, ex);
        }
        return miLista;
    }
    
    public void vaciarDatos(){
        Lista <E> miLista = new Lista();
        try{
            salida = new ObjectOutputStream(new FileOutputStream("fichero.txt"));
            salida.writeObject(miLista);
            salida.close();
        }catch(IOException ex){
            System.out.println("No se encontraron los datos");
        }
    }
}
