package Modelo;

import java.util.GregorianCalendar;

public interface CalcularFechas {
    public String tiempoCompra(); 
}
