package Modelo;

import Controlador.ControlErrores;
import java.io.Serializable;
import java.util.Calendar;
import java.util.GregorianCalendar;

public class Coche implements CalcularFechas, Serializable{
    private int numero;
    private String titular;
    private transient String contraseña;
    private int km;
    private double precio;
    private GregorianCalendar fechaCompra;

    public Coche(int numero, String titular, String contraseña, int km, double precio, GregorianCalendar fechaCompra) {
        this.numero = numero;
        this.titular = titular;
        this.contraseña = contraseña;
        this.km = km;
        this.precio = precio;
        this.fechaCompra = fechaCompra;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public String getTitular() {
        return titular;
    }

    public void setTitular(String titular) {
        this.titular = titular;
    }

    public String getContraseña() {
        return contraseña;
    }
    
    public int getKm() {
        return km;
    }

    public void setKm(int km) {
        this.km = km;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public GregorianCalendar getFechaCompra() {
        return fechaCompra;
    }

    public void setFechaCompra(GregorianCalendar fechaCompra) {
        this.fechaCompra = fechaCompra;
    }

    @Override
    public String tiempoCompra() {
        GregorianCalendar hoy = new GregorianCalendar();
        int años = hoy.get(GregorianCalendar.YEAR) - this.fechaCompra.get(GregorianCalendar.YEAR);
        int meses = this.fechaCompra.get(GregorianCalendar.MONTH) - hoy.get(GregorianCalendar.MONTH);
        
        if(meses < 0){
            años--;
            meses += 12;
        }
        
        return "    Antiguedad : " + años + " anos " + meses + " meses";
    }
    
    public void ControlFecha(GregorianCalendar fechaCompra) throws ControlErrores{
        if(fechaCompra != (GregorianCalendar) fechaCompra ){
            throw new ControlErrores("ERROR: Tipo fecha incorrecta");
        }
    }
    
    public boolean fechaMinima(){
        GregorianCalendar fechaMinima = new GregorianCalendar(2000, Calendar.JANUARY, 01);
        if(this.getFechaCompra().before(fechaMinima)){
            return false;
        }else return true;
    }
}
