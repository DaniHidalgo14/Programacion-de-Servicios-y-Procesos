package Modelo;

import Controlador.ControlErrores;
import java.io.Serializable;
import java.util.GregorianCalendar;


public class Combustion extends Coche implements Serializable{
    private double emisionesCO2;
    private double maxEmisionesCO2;
    private int incrementoAnual;

    public Combustion(double emisionesCO2, double maxEmisionesC02, 
            int incrementoAnual, int numero, String titular, String contraseña, 
            int km, double precio, GregorianCalendar fechaCompra) {
        
        super(numero, titular, contraseña, km, precio, fechaCompra);
        this.emisionesCO2 = emisionesCO2;
        this.maxEmisionesCO2 = maxEmisionesC02;
        this.incrementoAnual = incrementoAnual;
    }

    

    public double getEmisionesCO2() {
        return emisionesCO2;
    }

    public void setEmisionesCO2(double emisionesCO2) {
        this.emisionesCO2 = emisionesCO2;
    }

    public double getMaxEmisionesC02() {
        return maxEmisionesCO2;
    }

    public void setMaxEmisionesC02(double maxEmisionesC02) {
        this.maxEmisionesCO2 = maxEmisionesC02;
    }

    public int getIncrementoAnual() {
        return incrementoAnual;
    }

    public void setIncrementoAnual(int incrementoAnual) {
        this.incrementoAnual = incrementoAnual;
    }
    
    @Override
    public String toString(){
        return "- Coche combustion nº: " + getNumero() + this.tiempoCompra() + "\n";
    }
    
    public boolean ControlEmisiones() {
        if(emisionesCO2 > maxEmisionesCO2){
            return true;
        } else {
            this.emisionesCO2 = maxEmisionesCO2;
            return false;
        }
    }
}
