package Modelo;

import java.io.Serializable;
import java.util.GregorianCalendar;

public class Electrico extends Coche implements Serializable{
    private int consumoKWH;
    private int bateriaKWH;

    public Electrico(int consumoKWH, int bateriaKWH, int numero, String titular, String contraseña, 
           int km, double precio, GregorianCalendar fechaCompra) {
        super(numero, titular, contraseña, km, precio, fechaCompra);
        this.consumoKWH = consumoKWH;
        this.bateriaKWH = bateriaKWH;
    }

    public int getConsumoKWH() {
        return consumoKWH;
    }

    public void setConsumoKWH(int consumoKWH) {
        this.consumoKWH = consumoKWH;
    }

    public int getBateriaKWH() {
        return bateriaKWH;
    }

    public void setBateriaKWH(int bateriaKWH) {
        this.bateriaKWH = bateriaKWH;
    }
    
    @Override
    public String toString(){
        return "- Coche electrico nº: " + getNumero() + this.tiempoCompra() + "\n";
    }
}
